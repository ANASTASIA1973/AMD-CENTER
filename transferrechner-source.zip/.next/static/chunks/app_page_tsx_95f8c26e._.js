(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_95f8c26e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_95f8c26e._.js",
  "chunks": [
    "static/chunks/d584a_next_dist_512a4d9c._.js",
    "static/chunks/app_components_RouteStep_jsx_02f75b24._.js"
  ],
  "source": "dynamic"
});
