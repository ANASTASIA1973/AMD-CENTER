(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_jsx_a274f924._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_jsx_a274f924._.js",
  "chunks": [
    "static/chunks/_94004d08._.js"
  ],
  "source": "dynamic"
});
