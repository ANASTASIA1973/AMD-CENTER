(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_8d94d3c9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_8d94d3c9._.js",
  "chunks": [
    "static/chunks/_35cc418f._.js"
  ],
  "source": "dynamic"
});
