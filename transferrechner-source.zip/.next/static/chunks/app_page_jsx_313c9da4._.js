(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_jsx_313c9da4._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_jsx_313c9da4._.js",
  "chunks": [
    "static/chunks/app_13d72377._.js"
  ],
  "source": "dynamic"
});
