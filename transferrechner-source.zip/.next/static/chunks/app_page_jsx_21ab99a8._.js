(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_jsx_21ab99a8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_jsx_21ab99a8._.js",
  "chunks": [
    "static/chunks/app_66d3c57c._.js"
  ],
  "source": "dynamic"
});
