(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_e1358e69._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_e1358e69._.js",
  "chunks": [
    "static/chunks/_3d896552._.js"
  ],
  "source": "dynamic"
});
