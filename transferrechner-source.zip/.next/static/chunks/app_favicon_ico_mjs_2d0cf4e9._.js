(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_favicon_ico_mjs_2d0cf4e9._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_favicon_ico_mjs_2d0cf4e9._.js",
  "chunks": [
    "static/chunks/d584a_next_dist_7ccf0bf2._.js"
  ],
  "source": "dynamic"
});
