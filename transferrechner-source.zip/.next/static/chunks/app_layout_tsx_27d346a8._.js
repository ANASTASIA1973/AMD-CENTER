(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_27d346a8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_27d346a8._.js",
  "chunks": [
    "static/chunks/[root of the server]__772746f6._.css",
    "static/chunks/_937f5e51._.js"
  ],
  "source": "dynamic"
});
